# DEVOPS LAB – EXPERIMENT 3

## Practice Source Code Management on GitHub

**Aim:** To practice source code management using Git and GitHub by uploading, modifying, and maintaining the FastAPI CRUD application developed in Experiment 1.

### 1. Requirements

- Git installed
- GitHub account
- FastAPI CRUD project (`app.py`)
- Terminal or VS Code

### 2. Create the project files

Project structure:

```text
devops-week1/
├── app.py
├── requirements.txt
└── .gitignore
```

Create `requirements.txt`:

```text
fastapi
uvicorn
```

Create `.gitignore`:

```text
venv/
__pycache__/
*.pyc
.env
.DS_Store
```

### 3. Initialize the Git repository

Open the terminal inside the project directory.

```bash
git init
git status
git add app.py requirements.txt .gitignore
git commit -m "Initial commit - FastAPI CRUD API"
```

### 4. Create a repository on GitHub

1. Visit https://github.com/
2. Click **New repository**.
3. Enter the repository name as `devops-lab`.
4. Select Public or Private.
5. Create the repository without adding a README or other files.

### 5. Connect the local repository to GitHub

Replace `<repository-url>` with the URL of your newly created repository.

```bash
git branch -M main
git remote add origin <repository-url>
git remote -v
git push -u origin main
```

The source code is now available in your GitHub repository.

### 6. Create a feature branch

Create a separate branch to add a feature without directly modifying the main branch.

```bash
git switch -c feature/item-search
```

Add the following endpoint to the existing `app.py`:

```python
@app.get("/items/search/{name}")
def search_items(name: str):
    return [
        {"id": item_id, **item}
        for item_id, item in items.items()
        if name.lower() in item["name"].lower()
    ]
```

This endpoint searches for items by name, ignoring case.

### 7. Commit and push the changes

```bash
git status
git add app.py
git commit -m "Add item search API"
git push -u origin feature/item-search
```

### 8. Create a Pull Request

1. Open the repository on GitHub.
2. Select the option to create a pull request for `feature/item-search`.
3. Set the base branch to `main`.
4. Review the code changes.
5. Create and merge the pull request.

A pull request allows changes to be reviewed before they are merged into the main branch.

### 9. Synchronize the local repository

```bash
git switch main
git pull origin main
git log --oneline --graph
```

### 10. Verify the application

Run the application:

```bash
source venv/bin/activate
uvicorn app:app --reload
```

Open http://127.0.0.1:8000/docs and test the new endpoint.

For example, create an item named `Docker`, then search using:

```text
GET /items/search/doc
```

The response should contain the matching item.

### 11. Important Git commands

| Command | Purpose |
|---|---|
| `git status` | Check file changes |
| `git add .` | Stage changes |
| `git commit -m "message"` | Save a commit |
| `git branch` | List branches |
| `git switch -c branch` | Create and switch branches |
| `git merge branch` | Merge a branch |
| `git push` | Upload commits |
| `git pull` | Fetch and integrate remote changes |
| `git clone URL` | Copy a remote repository |
| `git log --oneline` | View commit history |

### Result

Successfully practiced source code management using Git and GitHub by creating a repository, tracking changes, developing a feature branch, pushing code, creating a pull request, and merging changes into the main branch.