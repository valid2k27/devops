# DEVOPS LAB – EXPERIMENT 5

## Develop a Simple Containerized Application Using Docker

**Aim:** To develop and containerize a FastAPI application using Docker and execute it inside a container.

### 1. Requirements

- Python
- FastAPI and Uvicorn
- Docker Desktop
- VS Code or any code editor

### 2. Project Structure

```text
devops-week1/
├── app.py
├── requirements.txt
├── Dockerfile
└── .dockerignore
```

Use the same `app.py` CRUD application from Experiment 1.

### 3. Create requirements.txt

```text
fastapi
uvicorn
```

### 4. Create Dockerfile

Create a file named `Dockerfile` in the project directory.

```dockerfile
FROM python:3.12-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app.py .

EXPOSE 8000

CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 5. Create .dockerignore

```text
venv/
__pycache__/
*.pyc
.git/
.env
```

This excludes unnecessary files from the Docker build context.

### 6. Build the Docker Image

Open the terminal in the directory containing `app.py` and `Dockerfile`.

```bash
docker --version
docker build -t items-api:1.0 .
docker images
```

**Explanation:**
- `docker build` builds the image.
- `-t items-api:1.0` assigns an image name and version.
- `.` specifies the current directory as the build context.

### 7. Run the Container

```bash
docker run -d --name items-api -p 8000:8000 items-api:1.0
```

Check whether the container is running:

```bash
docker ps
docker logs items-api
```

### 8. Test the Application

Open the following URL:

http://localhost:8000/docs

Test the CRUD operations:

| Method | Endpoint | Operation |
|---|---|---|
| POST | `/items` | Create an item |
| GET | `/items` | Retrieve all items |
| GET | `/items/1` | Retrieve one item |
| PATCH | `/items/1` | Update an item |
| DELETE | `/items/1` | Delete an item |

### 9. Manage the Container

```bash
docker stop items-api
docker start items-api
docker restart items-api
docker inspect items-api
docker logs items-api
```

Remove the container after testing:

```bash
docker rm -f items-api
```

### 10. Important Docker Commands

| Command | Purpose |
|---|---|
| `docker build` | Build an image |
| `docker run` | Create and start a container |
| `docker ps` | List running containers |
| `docker images` | List images |
| `docker logs` | View container logs |
| `docker stop` | Stop a container |
| `docker rm` | Remove a container |
| `docker rmi` | Remove an image |

### Result

Successfully developed and containerized a FastAPI CRUD application using Docker. The application was executed inside a container and tested through its REST API endpoints.