EXPERIMENT 2: EXPLORE GIT AND GITHUB COMMANDS

Aim: To explore Git and GitHub commands for version control and source code management.

1. Configure Git

git --version
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git config --global --list

2. Initialize Repository

git init
git status

3. Add and Commit Files

git add app.py
git commit -m "Initial commit"
git log --oneline

4. Track Changes

git status
git diff
git diff --staged
git add .
git commit -m "Update application"
git show

5. Branch Management

git branch
git switch -c feature/update-api
git switch main
git merge feature/update-api
git branch -d feature/update-api

6. Connect to GitHub

Create an empty repository on GitHub and copy its URL.

git branch -M main
git remote add origin <repository-url>
git remote -v
git push -u origin main

Replace <repository-url> with your actual repository URL.

7. Synchronize Changes

git pull origin main
git fetch origin
git push
git clone <repository-url>

8. Undo Changes

git restore app.py
git restore --staged app.py
git reset --soft HEAD~1
git revert HEAD

9. Create .gitignore

venv/
__pycache__/
*.pyc
.env
.DS_Store

10. Result

Successfully explored Git and GitHub commands for repository initialization, file tracking, commits, branch management, and remote repository synchronization.