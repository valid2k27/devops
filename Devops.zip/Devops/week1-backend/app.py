from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()
items = {}
counter = 1

class Item(BaseModel):
    name: str
    description: str = ""

@app.post("/items")
def create_item(item: Item):
    global counter
    items[counter] = item.model_dump()
    result = {"id": counter, **items[counter]}
    counter += 1
    return result

@app.get("/items")
def get_items():
    return [
        {"id": i, **item}
        for i, item in items.items()
    ]

@app.get("/items/{item_id}")
def get_item(item_id: int):
    if item_id not in items:
        raise HTTPException(404, "Item not found")
    return {"id": item_id, **items[item_id]}

@app.patch("/items/{item_id}")
def update_item(item_id: int, item: dict):
    if item_id not in items:
        raise HTTPException(404, "Item not found")
    items[item_id].update(item)
    return {"id": item_id, **items[item_id]}

@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    if item_id not in items:
        raise HTTPException(404, "Item not found")
    del items[item_id]
    return {"message": "Item deleted"}