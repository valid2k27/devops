EXPERIMENT 1: DEVELOP A SIMPLE BACKEND PROJECT WITH CRUD OPERATIONS

Aim: To develop a simple backend application using FastAPI that supports CRUD operations through REST APIs.

1. Install Dependencies

mkdir week1
cd week1

python3 -m venv venv
source venv/bin/activate

pip install fastapi uvicorn

2. Create app.py

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI()
items = {}
counter = 1

class Item(BaseModel):
    name: str
    description: str = ""

@app.post("/items")
def create_item(item: Item):
    global counter
    items[counter] = item.model_dump()
    result = {"id": counter, **items[counter]}
    counter += 1
    return result

@app.get("/items")
def get_items():
    return [
        {"id": i, **item}
        for i, item in items.items()
    ]

@app.get("/items/{item_id}")
def get_item(item_id: int):
    if item_id not in items:
        raise HTTPException(404, "Item not found")
    return {"id": item_id, **items[item_id]}

@app.patch("/items/{item_id}")
def update_item(item_id: int, item: dict):
    if item_id not in items:
        raise HTTPException(404, "Item not found")
    items[item_id].update(item)
    return {"id": item_id, **items[item_id]}

@app.delete("/items/{item_id}")
def delete_item(item_id: int):
    if item_id not in items:
        raise HTTPException(404, "Item not found")
    del items[item_id]
    return {"message": "Item deleted"}

3. Run the Application

uvicorn app:app --reload

Open the following URL:

http://127.0.0.1:8000/docs

4. Test CRUD Operations

Operation

Method

Endpoint

Create

POST

/items

Read all

GET

/items

Read one

GET

/items/1

Update

PATCH

/items/1

Delete

DELETE

/items/1

Sample POST request body:

{
  "name": "Docker",
  "description": "Containerization tool"
}

Expected response:

{
  "id": 1,
  "name": "Docker",
  "description": "Containerization tool"
}

5. Result

Successfully developed and tested a FastAPI backend application implementing Create, Read, Update, and Delete operations through REST APIs.