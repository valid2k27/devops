# DEVOPS LAB – EXPERIMENT 4

## Explore Docker Commands for Container Management

**Aim:** To explore Docker commands for managing images and containers and understand the container lifecycle.

### 1. Requirements

- Docker Desktop installed and running
- Terminal or VS Code
- Internet connection to download Docker images

### 2. Check Docker Installation

```bash
docker --version
docker info
docker run hello-world
```

### 3. Download and Manage Images

```bash
docker pull nginx
docker images
docker image ls
docker image inspect nginx
docker history nginx
```

**Explanation:**
- `docker pull nginx` downloads the Nginx image.
- `docker images` lists locally available images.
- `docker image inspect nginx` displays image details.
- `docker history nginx` displays the image's build history.

### 4. Create and Run a Container

```bash
docker run -d --name web -p 8080:80 nginx
```

**Explanation:**
- `-d`: Runs the container in the background.
- `--name web`: Assigns the name `web`.
- `-p 8080:80`: Maps host port 8080 to container port 80.
- `nginx`: Specifies the Docker image.

Open http://localhost:8080 in your browser to view the Nginx welcome page.

### 5. List Containers

```bash
docker ps
docker ps -a
docker container ls
docker container ls -a
```

- `docker ps` lists running containers.
- `docker ps -a` lists all containers, including stopped containers.

### 6. Stop, Start, and Restart Containers

```bash
docker stop web
docker start web
docker restart web
```

### 7. View Container Information

```bash
docker logs web
docker logs -f web
docker inspect web
docker stats
docker top web
docker port web
```

**Explanation:**
- `docker logs web`: Displays container logs.
- `docker logs -f web`: Follows logs continuously.
- `docker inspect web`: Shows detailed configuration.
- `docker stats`: Displays resource usage.
- `docker top web`: Shows processes inside the container.
- `docker port web`: Displays port mappings.

Press `Ctrl + C` to stop following logs.

### 8. Execute Commands Inside a Container

```bash
docker exec -it web sh
```

Inside the container:

```bash
ls
exit
```

### 9. Remove Containers and Images

```bash
docker stop web
docker rm web
docker rmi nginx
```

Alternatively, forcefully remove the container:

```bash
docker rm -f web
```

Remove an image only when no remaining container references it.

### 10. Containerize the FastAPI Application

Use the same `app.py` CRUD application from Experiment 1.

Create `requirements.txt`:

```text
fastapi
uvicorn
```

Create a file named `Dockerfile`:

```dockerfile
FROM python:3.12-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY app.py .

EXPOSE 8000

CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000"]
```

Build and run the image:

```bash
docker build -t items-api:1.0 .
docker images
docker run -d --name items-api -p 8000:8000 items-api:1.0
docker ps
docker logs items-api
```

Open http://localhost:8000/docs to test the CRUD APIs.

### 11. Clean Up Docker Resources

```bash
docker rm -f items-api
docker container prune
docker image prune
docker system df
```

Use cleanup commands carefully because they can remove unused containers and images.

### Result

Successfully explored Docker commands for downloading images, creating and managing containers, inspecting logs, executing commands inside containers, and running a containerized FastAPI application.